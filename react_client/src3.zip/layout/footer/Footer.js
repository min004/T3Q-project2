const Footer = () => {
    return (
      <footer>
        <h2>This is Footer</h2>
      </footer>
    )
  }
  
  export default Footer