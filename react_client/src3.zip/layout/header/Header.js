const Header = () => {
    return (
      <header>
        <h2>This is Header</h2>
      </header>
    )
  }
  
  export default Header